# UG DATA VPN — v0.3 cloud-build project

This Android project includes a native screen, a CONNECT/DISCONNECT control, WireGuard tunnel integration, configuration import, and basic transfer counters.

## Build an APK for free from an Android phone

This project includes a GitHub Actions workflow. You do not need Android Studio or a bank card, but you do need a free GitHub account and must upload this project yourself.

1. Download and unzip this project on your phone (a file manager that can extract ZIP files is sufficient).
2. In your phone browser, sign in to GitHub and create a **new public repository** named `ug-data-vpn`. Do not upload any VPN `.conf` file, private key, password, or server credentials.
3. Upload the contents of this folder to the repository's `main` branch. Make sure `.github/workflows/android-apk.yml` is included. GitHub's web upload may require uploading folders through its web interface or GitHub mobile/browser workflow.
4. Open the repository's **Actions** tab, select **Build UG DATA VPN APK**, and tap **Run workflow** if it has not started automatically.
5. When the run succeeds, open that run and download the artifact named `UG-DATA-VPN-debug-apk`. Extract it and install `app-debug.apk`. Android may ask you to allow installation from that browser/file manager.

## First use

Open the app, tap **IMPORT VPN CONFIG (.conf)**, select a valid WireGuard client configuration from a server you are authorized to use, then tap **CONNECT** and approve Android's VPN permission prompt.

## Important limitations

- This is a debug build workflow, not a Play Store release. The APK is not signed with a personal release key.
- A real server and valid client `.conf` are required. This project does not provision or include a VPN server.
- The CONNECT button only enables after a config is imported.
- Data counters show tunnel transfer totals. They are not a measurement of Airtel billing.
- No billing bypass is implemented. Airtel must authorize and provision any zero-rated service. No app can legitimately force ordinary paid-bundle traffic to be billed as free.
- Compression, caching, ad filtering, HTTP proxy tunnelling, automatic reconnect, and Airtel zero-rating integration are not implemented in this build.
- The project has not been compiled or tested in this environment. The cloud workflow will reveal build errors; do not install an artifact unless the workflow reports success.
