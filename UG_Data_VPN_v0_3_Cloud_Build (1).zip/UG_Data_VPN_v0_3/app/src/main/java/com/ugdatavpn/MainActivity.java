package com.ugdatavpn;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Statistics;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;

import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_CONFIG = 41;
    private static final int VPN_PERMISSION = 42;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private GoBackend backend;
    private Config config;
    private VpnTunnel tunnel;
    private TextView state, rx, tx, profile;
    private Button connect, importConfig;
    private boolean connected = false;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        backend = new GoBackend(this);
        tunnel = new VpnTunnel();
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(28, 44, 28, 28);
        root.setBackgroundColor(0xFF101820);

        TextView title = text("UG DATA VPN", 28, 0xFFFFFFFF, true);
        TextView subtitle = text("AIRTEL UGANDA EDITION", 12, 0xFFAAB8C5, true);
        state = text("Disconnected", 21, 0xFFFFFFFF, true);
        TextView ready = text("Import your WireGuard configuration to get started", 13, 0xFFAAB8C5, false);
        connect = new Button(this);
        connect.setText("CONNECT");
        connect.setTextSize(18);
        connect.setAllCaps(true);
        connect.setEnabled(false);
        connect.setOnClickListener(v -> toggleVpn());
        importConfig = new Button(this);
        importConfig.setText("IMPORT VPN CONFIG (.conf)");
        importConfig.setOnClickListener(v -> chooseConfig());
        profile = text("Profile: Airtel daily / weekly", 14, 0xFFFFFFFF, false);
        rx = text("Data received: 0 MB", 14, 0xFFFFFFFF, false);
        tx = text("Data sent: 0 MB", 14, 0xFFFFFFFF, false);
        TextView note = text("UG DATA VPN uses a VPN server you are authorized to access. It does not bypass Airtel billing or make ordinary data free. Data savings vary by app and content.", 12, 0xFFAAB8C5, false);

        add(root,title,0,12); add(root,subtitle,0,44); add(root,state,0,14); add(root,ready,0,28);
        add(root,connect,0,16); add(root,importConfig,0,28); add(root,profile,0,10); add(root,rx,0,8); add(root,tx,0,18); add(root,note,0,0);
        setContentView(root);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setGravity(Gravity.CENTER); return t;
    }
    private void add(LinearLayout root, View view, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, view instanceof Button ? -2 : -2);
        p.topMargin = top; p.bottomMargin = bottom; root.addView(view,p);
    }

    private void chooseConfig() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_CONFIG);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if (request == PICK_CONFIG && result == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                config = Config.parse(in);
                connect.setEnabled(true);
                state.setText("Configuration loaded");
                Toast.makeText(this,"VPN configuration imported",Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                config = null; connect.setEnabled(false);
                Toast.makeText(this,"Could not read this config: " + e.getMessage(),Toast.LENGTH_LONG).show();
            }
        } else if (request == VPN_PERMISSION && result == RESULT_OK) {
            startTunnel();
        }
    }

    private void toggleVpn() {
        if (config == null) { Toast.makeText(this,"Import a .conf file first",Toast.LENGTH_SHORT).show(); return; }
        if (connected) stopTunnel();
        else {
            Intent prepare = GoBackend.VpnService.prepare(this);
            if (prepare != null) startActivityForResult(prepare, VPN_PERMISSION);
            else startTunnel();
        }
    }

    private void startTunnel() {
        connect.setEnabled(false);
        worker.execute(() -> {
            try {
                backend.setState(tunnel, Tunnel.State.UP, config);
                connected = true;
                runOnUiThread(() -> { state.setText("Connected"); connect.setText("DISCONNECT"); connect.setEnabled(true); refreshStats(); });
            } catch (Exception e) {
                connected = false;
                runOnUiThread(() -> { state.setText("Connection failed"); connect.setText("CONNECT"); connect.setEnabled(true); Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show(); });
            }
        });
    }

    private void stopTunnel() {
        connect.setEnabled(false);
        worker.execute(() -> {
            try { backend.setState(tunnel, Tunnel.State.DOWN, null); } catch (Exception ignored) { }
            connected = false;
            runOnUiThread(() -> { state.setText("Disconnected"); connect.setText("CONNECT"); connect.setEnabled(true); });
        });
    }

    private void refreshStats() {
        try {
            Statistics s = backend.getStatistics(tunnel);
            rx.setText("Data received: " + mb(s.totalRx()) + " MB");
            tx.setText("Data sent: " + mb(s.totalTx()) + " MB");
        } catch (Exception ignored) { }
    }
    private String mb(long bytes) { return String.format(java.util.Locale.US,"%.2f",bytes / 1048576.0); }

    @Override protected void onDestroy() { super.onDestroy(); worker.shutdown(); }

    private static final class VpnTunnel implements Tunnel {
        @Override public String getName() { return "ug-data-vpn"; }
        @Override public void onStateChange(State newState) { }
    }
}
