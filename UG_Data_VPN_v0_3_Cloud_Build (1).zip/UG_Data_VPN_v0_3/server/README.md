# VPN server setup

The Android client requires a WireGuard server and a matching client configuration. The server must be yours or one you are authorized to use. Hosting providers must permit UDP traffic and IP forwarding. A free-hosting offer is not guaranteed to support these features. Do not paste private keys or server credentials into public repositories or chats.

The earlier v0.2 server script is not included in this cloud-build-only revision. Provision and secure a server before generating a client `.conf` file.
